<?php

interface Vehicle{
    public function getWeight();
    public function getPlaque();
    public function getColor();
    public function getType();
}

