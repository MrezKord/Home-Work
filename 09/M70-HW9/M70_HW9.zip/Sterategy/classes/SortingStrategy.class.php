<?php

namespace classes;

interface SortingStrategy {
    public function getSortedSet($set);
}
