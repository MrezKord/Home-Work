<?php

// print_r($_SERVER['DOCUMENT_ROOT']);

// $a = fopen('Data/post.log', 'r');
// $container = [];
// while(!feof($a)) {
//     $container[] = fgets($a);
// }

// // print_r($container);
// $b = unserialize($container[0]);

// print_r($b);
// ?>

