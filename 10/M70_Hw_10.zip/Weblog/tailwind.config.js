module.exports = {
  content: ["./Project/**/*.{html,js,php}"],
  theme: {
    extend: {},
  },
  plugins: [],
}